let nextbox = document.getElementById('nextbox');
      let last_submit = null;
      
      let real_percentage = document.getElementById('real-percentage');
      let fake_percentage = document.getElementById('fake-percentage');
      let bar = document.getElementById('bar');
      let message = document.getElementById('message');
      
      function update_graph(result) {
          if (result === null) {
              real_percentage.innerHTML = '';
              fake_percentage.innerHTML = '';
              bar.style.width = '50%';
              message.innerHTML = '';
          } else {
              let percentage = result.real_probability;
              real_percentage.innerHTML = (100 * percentage).toFixed(2) + '%';
              fake_percentage.innerHTML = (100 * (1 - percentage)).toFixed(2) + '%';
              bar.style.width = (100 * percentage).toFixed(2) + '%';
              if (result.used_tokens === result.all_tokens) {
                  message.innerHTML = `Detection based on ${result.used_tokens} tokens`;
              } else {
                  message.innerHTML = `Dectection based on the first ${result.used_tokens} tokens among the total ${result.all_tokens}`;
              }
          }
      }
      
      // Process the raw text by breaking it down and sending requests
      function processText(text) {
          let words = text.split(" "); 
          let all_batches = [];
          let word_count = 0; 
          let current_batch = []
          let results = []
      
          for (let i = 0; i < words.length; i++) {
              let currentWord = words[i]; 
              current_batch.push(currentWord); 
              word_count++;
              if ((word_count >= 300 && currentWord[currentWord.length - 1] == '.') || word_count == 400) {
      
                  all_batches.push(current_batch); 
                  current_batch = [];
                  word_count = 0; 
              }
          }
          all_batches.push(current_batch);
          let number_of_batches = all_batches.length;
      
          for (let i = 0; i < number_of_batches; i++) {
              let req = new XMLHttpRequest();
              var text =  all_batches[i].join(" ");
              req.open('GET', 'https://openai-openai-detector.hf.space/' + '?' + text, true);
      
      
              req.onreadystatechange = () => {
                  if (req.readyState !== 4) return;
                  if (req.status !== 200) throw new Error("HTTP status: " + req.status);
                  results.push(JSON.parse(req.responseText));
      
                  if (results.length == number_of_batches) {
                      let total_tokens = nextbox.value.split(" ").length; 
                      let weighted_total_prob = 0; 
                      let total_words = 0;
                      for (let j = 0; j < number_of_batches; j++) {
                          let group_words = all_batches[j].length;
                          weighted_total_prob += group_words * results[j].real_probability;
                          total_words += group_words;
                      }
                      let avg_real_prob = weighted_total_prob / total_words;
                      update_graph({real_probability: avg_real_prob, used_tokens: total_tokens, all_tokens: total_tokens});
                  }
              };
              req.send();
          }
      }
      
      
      nextbox.oninput = () => {
          if (last_submit) {
              clearTimeout(last_submit);
          }
          if (nextbox.value.length === 0) {
              update_graph(null);
              return;
          }
          message.innerText = 'Detecting AI usage ...';
          last_submit = setTimeout(() => {
              if (nextbox.value.length === 0) {
                  update_graph(null);
                  return;
              }
              processText(nextbox.value)
              
          }, 1000);
      };
      
      window.addEventListener('DOMContentLoaded', () => {
          nextbox.focus();
      });
      
      function parseFile() {
        // Get the selected file
        var file = document.getElementById("fileInput").files[0];
        var fileReader = new FileReader();
        if (file.type === 'application/pdf') {
          // Parse the PDF file
          fileReader.onload = function() {
            var pdfData = new Uint8Array(this.result);
      
            pdfjsLib.getDocument(pdfData).promise.then(function(pdf) {
              pdf.getPage(1).then(function(page) {
                  page.getTextContent().then(function(textContent) {
                      var text = textContent.items.filter(i => i.str !== '●').map(i => i.str).join('')
                      document.getElementById("nextbox").innerHTML = text;
                      processText(text); 
                  });
              });
            });
          };
          fileReader.readAsArrayBuffer(file);
        } else if (file.type.startsWith('text')) {
          console.log(file);
          fileReader.onload = function() {
              var text = fileReader.result;
              console.log("got text", text)
              document.getElementById("nextbox").innerHTML = text;
              processText(text); 
          };
          fileReader.readAsText(file);
        }
        else {
          // Handle other file types
          alert('Unsupported file type');
        }
      }